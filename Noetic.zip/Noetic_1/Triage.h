//
// Created by aaliy on 2021-11-06.
//

#ifndef UNNAMED_PROJ_TRIAGE_H
#define UNNAMED_PROJ_TRIAGE_H
int getMoodRating();
int goodMood();
int notSoGoodMood (int moodRating);
void resourcesAndCare (int count, int YesorNo);
void Default (void);
void breathing (void);
#endif //UNNAMED_PROJ_TRIAGE_H
